package com.splitnotsowise.utilities;

import com.splitnotsowise.exceptions.InvalidInputException;
import com.splitnotsowise.command.*;
import com.splitnotsowise.communication.Server;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;


public class CommandExecutor {
    private static HashMap<String, Command> commands;
    private boolean hasUserLogIn = false;

    static {
        commands = new HashMap<>();

        commands.put("register", new RegisterCommand());
        commands.put("login", new LoginCommand());
        commands.put("add-friend", new AddFriendCommand());
        commands.put("create-group", new CreateGroupCommand());
        commands.put("show-history", new ShowHistoryCommand());
        commands.put("split-group", new SplitWithGroupCommand());
        commands.put("received-payment", new ClaimReceivedPaymentCommand());
        commands.put("received-payment-group", new ClaimReceivedPaymentFromGroupCommand());
        commands.put("get-status", new GetStatusCommand());
        commands.put("split", new SplitCommand());
        commands.put("help", new HelpCommand());

    }

    public void executeCommand(String username, String commandLine, Server server, PrintWriter writer) throws InvalidInputException {

        String[] commandLineContents = getCommandLineContents(commandLine);

        if (!commands.containsKey(commandLineContents[0])) {
            throw new InvalidInputException(username, writer);
        }

        commands.get(commandLineContents[0]).execute(username, commandLineContents, server, writer);
    }

    private String[] getCommandLineContents(String commandLine) {
        commandLine = commandLine.trim();

        String[] commandLineContents = commandLine.split(" ");

        return Arrays.copyOfRange(commandLineContents, 0, commandLineContents.length);
    }
}
