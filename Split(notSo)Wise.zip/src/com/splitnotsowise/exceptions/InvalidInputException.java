package com.splitnotsowise.exceptions;

import java.io.PrintWriter;
import java.util.Scanner;

public class InvalidInputException extends Exception {
    public InvalidInputException(String clientUsername, PrintWriter writer) {
        System.err.println("Invalid input from " + clientUsername);
        writer.println("Invalid input, use 'help' for further information");
        writer.println(new Scanner(System.in).nextLine());
    }
}
