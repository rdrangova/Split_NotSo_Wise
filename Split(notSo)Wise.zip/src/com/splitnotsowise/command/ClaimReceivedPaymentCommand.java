package com.splitnotsowise.command;

import com.splitnotsowise.exceptions.InvalidInputException;
import com.splitnotsowise.utilities.User;
import com.splitnotsowise.communication.Server;

import java.io.PrintWriter;
import java.util.Arrays;

public class ClaimReceivedPaymentCommand implements Command {

    private static final int INDEX_OF_PAYED_AMOUNT = 1;
    private static final int INDEX_OF_PAYER_USERNAME = 2;
    private static final int START_INDEX_OF_PAYMENT_REASON = 3;

    @Override
    public void execute(String clientUsername, String[] content, Server server, PrintWriter writer) throws InvalidInputException {

        if (content.length < 4) {
            throw new InvalidInputException(clientUsername, writer);

        } else {

            double amount = Double.parseDouble(content[INDEX_OF_PAYED_AMOUNT]);
            String payerUsername = content[INDEX_OF_PAYER_USERNAME];

            String reason = String.join(" ", Arrays.copyOfRange(content, START_INDEX_OF_PAYMENT_REASON, content.length));

            User receiver = server.getRegisteredUser(clientUsername);
            receiver.receivePaymentFromFriend(payerUsername, amount, reason);
            server.addRegisteredUser(receiver);

            User debtor = server.getRegisteredUser(payerUsername);
            debtor.payFriend(clientUsername, amount, reason);
            server.addRegisteredUser(debtor);

            writer.println("You claimed payment from " + payerUsername + " successfully");
            //TODO notifications
        }
    }

}
