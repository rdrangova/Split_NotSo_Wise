package com.splitnotsowise.command;

import com.splitnotsowise.exceptions.InvalidInputException;
import com.splitnotsowise.utilities.Obligation;
import com.splitnotsowise.utilities.User;
import com.splitnotsowise.communication.Server;

import java.io.PrintWriter;
import java.util.Arrays;

public class SplitCommand implements Command {

    private static final int INDEX_OF_SPLIT_AMOUNT = 1;
    private static final int INDEX_OF_FRIEND_USERNAME = 2;
    private static final int START_INDEX_OF_REASON = 3;

    @Override
    public void execute(String clientUsername, String[] content, Server server, PrintWriter writer)
            throws InvalidInputException {

        if (content.length < 4) {
            throw new InvalidInputException(clientUsername, writer);
        } else {
            double amount = Double.parseDouble(content[INDEX_OF_SPLIT_AMOUNT]);
            String friendUsername = content[INDEX_OF_FRIEND_USERNAME];
            String reason = String.join(" ", Arrays.copyOfRange(content, START_INDEX_OF_REASON, content.length));

            if (!server.areFriends(clientUsername, friendUsername)) {
                writer.println("You can split sums only with friends");

            } else {
                double halfAmount = amount / 2;
                Obligation newObligation = new Obligation(halfAmount, reason);

                User creditor = server.getRegisteredUser(clientUsername);
                creditor.addObligationsToCurrentUser(friendUsername, newObligation);
                server.addRegisteredUser(creditor); //TODO why this is here

                User debtor = server.getRegisteredUser(friendUsername);
                debtor.addObligationsOfCurrentUser(clientUsername, newObligation);
                server.addRegisteredUser(debtor);
                //TODO notify debtor that he owes new money
                writer.println(amount + " split successfully between you and " + friendUsername);

            }
        }

    }

}
