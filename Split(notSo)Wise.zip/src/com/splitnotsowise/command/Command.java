package com.splitnotsowise.command;

import com.splitnotsowise.exceptions.InvalidInputException;
import com.splitnotsowise.communication.Server;

import java.io.PrintWriter;


public interface Command {

    void execute(String clientUsername, String[] content, Server server, PrintWriter writer) throws InvalidInputException;

    //TODO boolean isEnabled();
}
