package com.splitnotsowise.command;

import com.splitnotsowise.exceptions.InvalidInputException;
import com.splitnotsowise.utilities.Obligation;
import com.splitnotsowise.utilities.User;
import com.splitnotsowise.communication.Server;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashSet;

public class SplitWithGroupCommand implements Command {

    private static final int INDEX_OF_SPLIT_AMOUNT = 1;
    private static final int INDEX_OF_GROUP_NAME = 2;
    private static final int START_INDEX_OF_REASON = 3;

    @Override
    public void execute(String clientUsername, String[] content, Server server, PrintWriter writer)
            throws InvalidInputException {

        if (content.length < 4) {

            throw new InvalidInputException(clientUsername, writer);
        }
        double amount = Double.parseDouble(content[INDEX_OF_SPLIT_AMOUNT]);
        String groupName = content[INDEX_OF_GROUP_NAME];
        String reason = String.join(" ", Arrays.copyOfRange(content, START_INDEX_OF_REASON, content.length));

        if (server.getGroup(groupName) == null) {
            writer.println("Group with name " + groupName + "doesn't exist");
            throw new InvalidInputException(clientUsername, writer);
        } else {
            HashSet<String> group = server.getGroup(groupName);
            double splitAmount = amount / (double) group.size();

            Obligation newObligation = new Obligation(splitAmount, groupName, reason);
            User creditor = server.getRegisteredUser(clientUsername);

            for (String member : group) {
                User debtor = server.getRegisteredUser(member);
                debtor.addObligationsOfCurrentUser(clientUsername, newObligation);
                server.addRegisteredUser(debtor); //TODO same as in normal split
                //TODO write notifications for debtors

                creditor.addObligationsToCurrentUser(member, newObligation);
            }

            server.addRegisteredUser(creditor);
            writer.println(amount + " split successfully between members of " + groupName);
        }

    }

}
