package com.splitnotsowise.command;

import com.splitnotsowise.exceptions.InvalidInputException;
import com.splitnotsowise.communication.Server;
import com.splitnotsowise.utilities.User;

import java.io.PrintWriter;
import java.util.Arrays;

public class ClaimReceivedPaymentFromGroupCommand implements Command {
    private static final int INDEX_OF_PAYED_AMOUNT = 1;
    private static final int INDEX_OF_GROUP_NAME = 2;
    private static final int INDEX_OF_GROUP_MEMBER_USERNAME = 3;
    private static final int START_INDEX_OF_PAYMENT_REASON = 4;


    @Override
    public void execute(String clientUsername, String[] content, Server server, PrintWriter writer)
            throws InvalidInputException {

        if (content.length < 4) {
            throw new InvalidInputException(clientUsername, writer);

        } else {
            double amount = Double.parseDouble(content[INDEX_OF_PAYED_AMOUNT]);
            String groupName = content[INDEX_OF_GROUP_NAME];
            String groupMemberUsername = content[INDEX_OF_GROUP_MEMBER_USERNAME];
            String reason = String.join(" ", Arrays.copyOfRange(content, START_INDEX_OF_PAYMENT_REASON, content.length));

            User receiver = server.getRegisteredUser(clientUsername);
            receiver.receivePaymentFromGroupMember(groupMemberUsername, groupName, amount, reason);
            server.addRegisteredUser(receiver);

            User debtor = server.getRegisteredUser(groupMemberUsername);
            debtor.payGroup(groupMemberUsername, groupName, amount, reason);//TODO strange
            server.addRegisteredUser(debtor);

            writer.println("You get paid from " + groupMemberUsername + " from " + groupName + " successfully!");
        }
    }
}
